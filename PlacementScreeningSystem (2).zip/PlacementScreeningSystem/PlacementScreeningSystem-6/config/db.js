

const mongoose = require('mongoose');
const config = require('config'); // Assuming you're using the 'config' package

// Get the MongoDB URI from the config
const dbURI = config.get('mongoURI'); // Ensure you have a mongoURI in your config file

// Function to connect to the database
const connectDB = async () => {
  try {
    // Connect to MongoDB using Mongoose
    await mongoose.connect(dbURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true, // Optional: For unique indexes
    });
    console.log('MongoDB connected successfully');
  } catch (err) {
    console.error('MongoDB connection error:', err.message);
    process.exit(1); // Exit process with failure
  }
};

// Export the connectDB function
module.exports = connectDB;