function validatePassword() {
    var password = document.getElementById('password').value;
    var alertMessage = document.getElementById('password-alert');
    
    // Check if password is less than 6 characters
    if (password.length < 6) {
        alertMessage.style.display = 'block';  // Show alert message
    } else {
        alertMessage.style.display = 'none';  // Hide alert message
        alert("Login successful!");
    }
}

// To check dynamically while typing in the password field
document.getElementById('password').addEventListener('input', function() {
    var password = this.value;
    var alertMessage = document.getElementById('password-alert');
    
    if (password.length < 6) {
        alertMessage.style.display = 'block';
    } else {
        alertMessage.style.display = 'none';
    }
});